---
title: 7 circle
categories:
  - Shapes
tags:
  - number
  - numeral
---
