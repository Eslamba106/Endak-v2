---
title: 0 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
